def potegowanie(a, n):
    wynik = 1
    for i in bin(n)[2:]:
        wynik = wynik * wynik  
        if i == '1':        
            wynik = wynik * a
    return wynik
a = float(input("Podaj liczbę do spotęgowania: "))
n = int(input("Podaj potęgę: "))
print(f"Wynik: {potegowanie(a, n)}")