def zamiana(liczba, p1, p2):
    dlugosc = len(liczba)
    pierwszacyfra = int(liczba[0])
    for i in range(1, dlugosc):
        pierwszacyfra = pierwszacyfra * p1 + int(liczba[i])
    wynik = ""
    while pierwszacyfra > 0:
        wynik = str(pierwszacyfra % p2) + wynik
        pierwszacyfra = pierwszacyfra // p2
    if wynik != 0:
        return wynik
    
liczba = input("Podaj liczbe: ")
p1 = int(input("Podaj podstawe dla liczby: "))
p2 = int(input("Podaj podstawe do zamiany: "))
print(zamiana(liczba, p1, p2))
