def licz_kwadraty(liczba1, liczba2):
    suma = 0
    for cyfra in liczba1+liczba2:
        suma += int(cyfra)*int(cyfra)
    return suma

liczba1 = input("Wprowadź liczbe: ")
liczba2 = input("Wprowadź liczbe: ")
print(f'Suma kwadratów cyfr obu liczb wynosi {licz_kwadraty(liczba1, liczba2)}.')