def a_do_nbin(podstawa, potega): 
    if potega == '0':
         return 1 
    if potega == "1": 
        return podstawa 
    wynik = podstawa 
    n = len(potega)
    for i in range(1, n): 
        wynik *= wynik 
        if potega[i] == "1": 
            wynik *= podstawa 
    return wynik
podstawa = float(input("Podaj liczbe do spotegowania: "))
potega = int(input("Podaj potege: "))
print(a_do_nbin(podstawa, potega))