def dzielenie(liczba, podstawa, dzielnik):
    n = len(liczba)
    dzies = int(liczba[0])
    for i in range(1, n):
        dzies = dzies * podstawa + int(liczba[i])
    if dzies % dzielnik == 0:
        return "Prawda"
    else:
        return "Fałsz"
liczba = input("Podaj liczbe: ")
podstawa = int(input("Podaj podstawe: "))
dzielnik = int(input("Podaj dzielnik: "))
print(dzielenie(liczba, podstawa, dzielnik))
    