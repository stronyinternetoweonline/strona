def dodawanie(liczba1, liczba2, system):
    liczba1 = "0" + liczba1
    liczba2 = "0" + liczba2
    wynik=''
    pam=0
    for i in range(len(liczba1)-1, -1, -1):
        suma = int(liczba1[i] + liczba2[i]) + pam
        wynik = str(suma % system) + wynik
        pam = suma // system
    if pam > 0:
         wynik = str(pam) + wynik
    return wynik
system = int(input("Podaj system liczbowy: "))
liczba1 = input("Podaj pierwszą liczbę: ")
liczba2 = input("Podaj drugą liczbę: ")

while len(liczba1) != len(liczba2):
    if len(liczba1) > len(liczba2):
          liczba2 = "0" + liczba2
    else: 
         liczba1 = "0" + liczba1
print(dodawanie(liczba1, liczba2, system))

