def odejmowanie(liczba1, liczba2, system):
    liczba1 = "0" + liczba1
    liczba2 = "0" + liczba2
    wynik = ""
    pozyczenie = 0
    for i in range(len(liczba1)-1, -1, -1):
        roznica = int(liczba1[i]) - int(liczba2[i]) - pozyczenie
        if roznica < 0:
            roznica += system
            pozyczenie = 1
        else:
            pozyczenie = 0
        wynik = str(roznica) + wynik
    return wynik
liczba1 = (input("Podaj liczbe pierwsza: "))
liczba2 = (input("Podaj liczbe druga: "))
system = int(input("Podaj w jakim systemie: "))
print(odejmowanie(liczba1, liczba2, system))
while len(liczba1) != len(liczba2):
    if len(liczba1) > len(liczba2):
        liczba2 = "0" + liczba2
    else:
        liczba1 = "0" + liczba1
