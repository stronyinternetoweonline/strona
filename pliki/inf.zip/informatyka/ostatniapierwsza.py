def ostatnia_pierwsza(liczba):
    pierwsza = int(liczba[0])
    ostatnia = int(liczba[-1])
    return ostatnia == pierwsza
liczba = input("Podaj liczbe: ")
print(f"Wynik funkcji to: {ostatnia_pierwsza(liczba)}")