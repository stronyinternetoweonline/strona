
# def fiborek(n):
#     if n==1 or n==2 or n==3:
#         return 1
#     else:
#         return fiborek(n-1) + fiborek(n-2) + fiborek(n-3)
#
# def fiboite(n):
#     ppp=1
#     pp=1
#     p=1
#     for i in range(3, n):
#         wynik=p+pp+ppp
#         ppp=pp
#         pp=p
#         p=wynik
#     return p
#
# def CiagR(n):
#     if n==1:
#         return 0
#     elif n==2:
#         return 1
#     elif n%2==1:
#         return 0
#     else:
#         return ciagR(n-2)+2
n=input("który wyraz szukać? ")
while not n.isdecimal():
    n=input('Blad. Podaj liczbe naturalna')
n=int(n)
# print(f'{n} to wyraz ciagu = {fiborek(n)}')
# print(f'{n} to wyraz ciagu = {fiboite(n)}')
