

# pierwsza razy dwa plus kolejna
# def horner(binarna):
#     n = len(binarna)
#     wynik = (binarna[0])
#     for i in range(1, n):
#         wynik = wynik * 2 + binarna[i]
#     return wynik



# zamiana liczby z dowolnego systemu gdzie podstawa p należy do zbioru {2,3...,9} na dziesietny system
# def horner(binarna, p):
#     n = len(binarna)
#     wynik = (binarna[0])
#     for i in range(1, n):
#         wynik = wynik * p + binarna[i]
#     return wynik
# binarna1 = input('podaj liczbe w systemie binarnym')
# binarna2 = input('podaj liczbe w systemie binarnym')

# def suma(binarna1, binarna2):
#     wynik = ""
#     pam = 0
#     binarna1 = '0' + binarna1
#     binarna2 = '0' + binarna2
#     for i in range(len(binarna1)-1, -1, -1):
#         zmienna = int(binarna1[i]) + int(binarna2[i]) + pam
#         if zmienna > 1:
#             pam = 1
#             zmienna %= 2
#         else:
#             pam = 0
#         wynik = str(zmienna) + str(wynik)
#     if pam == 1:
#         return '1' + wynik
#     return wynik





# p=input('podaj podstawe systemu {2,3,...9}')
# p=int(p)
# binarna = input("Podaj liczbę: ")
# wynik = int(binarna, p)
# print(f'{binarna} w systemie {p}to {horner(binarna, p)}')

#
# while len(binarna1) < len(binarna2):
#     binarna1 = '0' + binarna1
# while len(binarna2) < len(binarna1):
#     binarna2 = '0' + binarna2
# print(binarna1)
# # print(binarna2)
# print(suma(binarna1, binarna2))
# wprowadzamy dwie liczby w systemie trojkowym i je dodajemy
# l1 = input('podaj liczbe w systemie trójkowym')
# l2 = input('podaj liczbe w systemie trójkowym')
# def suma(l1, l2):
#     wynik = ""
#     pam = 0
#     l1 = '0' + l1
#     l2 = '0' + l2
#     for i in range(len(l1)-1, -1, -1):
#         zmienna = int(l1[i]) + int(l2[i]) + pam
#         if zmienna > 2:
#             pam = 1
#             zmienna %= 3
#         else:
#             pam = 0
#         wynik = str(zmienna) + str(wynik)
#     if pam == 1:
#         return '1' + wynik
#     return wynik
#
# while len(l1) < len(l2):
#     l1 = '0' + l1
# while len(l2) < len(l1):
#     l2 = '0' + l2

# print(suma(l1, l2))
# wprowadzamy dwie liczby w piatkowym
# p1 = input('podaj liczbe w systemie piatkowym')
# p2 = input('podaj liczbe w systemie piatkowym')
# def suma(p1, p2):
#     wynik = ""
#     pam = 0
#     p1 = '0' + p1
#     p2 = '0' + p2
#     for i in range(len(p1)-1, -1, -1):
#         zmienna = int(p1[i]) + int(p2[i]) + pam
#         if zmienna > 4:
#             pam = 1
#             zmienna %= 5
#         else:
#             pam = 0
#         wynik = str(zmienna) + str(wynik)
#     if pam == 1:
#         return '1' + wynik
#     return wynik
#
# while len(p1) < len(p2):
#     p1 = '0' + p1
# while len(p2) < len(p1):
#     p2 = '0' + p2
# print(suma(p1, p2))
# w systemie dowolnym
p1 = input('podaj liczbe w systemie dowolnym')
p2 = input('podaj liczbe w systemie dowolnym')
def suma(p1, p2):
    wynik = ""
    pam = 0
    p1 = '0' + p1
    p2 = '0' + p2
    for i in range(len(p1)-1, -1, -1):
        zmienna = int(p1[i]) + int(p2[i]) + pam
        if zmienna > 4:
            pam = 1
            zmienna %= 5
        else:
            pam = 0
        wynik = str(zmienna) + str(wynik)
    if pam == 1:
        return '1' + wynik
    return wynik

while len(p1) < len(p2):
    p1 = '0' + p1
while len(p2) < len(p1):
    p2 = '0' + p2
print(suma(p1, p2, p))