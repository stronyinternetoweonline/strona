class Telefon:
    rodzaj = 'smartfon'

    def __init__(self, typ, model, cena):
        self.typ = typ
        self.model = model
        self.cena = cena

    @property
    def cena(self):
        return self.__cena
    @property
    def model(self):
        return sel.__model
    @model.setter
    def model(self, tekst):
        if isinstance(tekst,str):
            if tekst.isalnum():
               self.__model = tekst
            else:
                raise TypeError('Nie może mieć miejsc zerowych')
        else:
            raise
    @cena.deleter
    def cena(self):
        del self.__cena
    @property
    def typ(self):
        return self._typ
    @typ.setter
    def typ(self, tekst):
        if isinstance(tekst, str):
            self._typ=tekst
        else:
            raise TypeError('Typ musi być stringiem')
    # cena=property(fget=get_cena, fset=set_cena, fdel=del_cena)
    @cena.setter
    def cena(self, wartosc):
        if isinstance(wartosc, (int, float)):
            if wartosc>0:
                self.__cena=wartosc
            else:
                raise ValueError('Wartosc musi byc liczba dodatnia')
        else:
            raise TypeError('Cena musi byc typu int lub float')
    def __str__(self):
        return f'Towar: {Telefon.rodzaj},Typ: {self._typ}, Model: {self.model}, Cena: {self.__cena}'


telefon1 = Telefon('Samsung', "Galaxy", 5000)
telefon2 = Telefon('Iphone', '15', 6000)
telefon3=Telefon('Motorola', 'A15', -4000)
telefon2.model = '13'
telefon4=Telefon('LG', 'K9', 5000)
telefon1.cena(5000)
print(telefon1)
print(telefon3)
telefon3.cena = 1000

# dodawanie właściwości np. deleter itp. nazwana property i podstawiona pod nazwe ktora widzi uzytkownik


# zad. model musi byc stringiem i nie moze byc spacji ale moga byc litery i cyfry i prywatny