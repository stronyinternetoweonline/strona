#  klasa
class Telefon:
    rodzaj = "Smartfon"
    # wpisywanie przez uzytkownika poprzez konstruktor

    def __init__(self, typ, model, cena):
        self.typ = typ
        self.model = model
        self.cena = cena

    # metoda
    def opisz_tel(self):
        return f'Towar: {Telefon.rodzaj}, Typ: {self.typ}, Model: {self.model}, Cena: {self.cena}'
    def __str__(self):
        return self.opisz_tel()

# obiekty
telefon1 = Telefon('Samsung', 'Galaxy', 5000)
telefon2 = Telefon("Iphone", "15", 6000)
# zmiana modelu na 13 w telefonie2
telefon2.model = "13"
# zmiana rodzaju na smartphone w całej klasie
Telefon.rodzaj = 'smartphone'
# printowanie
print(telefon1)
print(telefon2)
print(Telefon.__dict__)
print(telefon1._Telefon.__cena)
# __str__() nie jest zdefiniowane, więc pokazuje domyślną reprezentację obiektu
# print(telefon1.__str__())

# pokaże słownik atrybutów klasy
# print(Telefon.__dict__)
# kazda klasa musi zawieriac konstruktor i funkcje string
