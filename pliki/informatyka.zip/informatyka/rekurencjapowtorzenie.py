def potegaI(n, a):
    wynik=1
    for i in range(n):
       wynik*=a
    return wynik
def potegaR(n, a):
    if n==0:
        return 1
    else:
        return potegaR(n-1, a)*a

a = float(input('Podaj liczbe rzeczywista: '))
n = int(input('Podaj liczbe naturalna: '))
print(potegaI(n, a))
print(potegaR(n, a))