# Dane a należy do R, n należy do naturalnych, a do potegi n
def potegowanie(a, n):
    wynik = a
    for i in range(1, len(binn)):
        wynik = wynik * wynik
        if binn[i] == 1:
            wynik *= a
    return wynik
a = float(input("Podaj liczbę do spotęgowania"))
n = int(input("Podaj potęge: "))
binn = bin(n)[2:]
print(potegowanie(a, binn))

# zadanie drugie 19.4
