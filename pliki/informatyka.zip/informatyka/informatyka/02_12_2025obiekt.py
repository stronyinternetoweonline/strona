# zajmujemy sie telefonami
# ----------------------------
# atrybuty ktore nie sa w konstruktoze to atrybuty klasy
# ------------------
# klasa ma obiekty
# tworzymy klase
class Telefon:
    rodzaj = 'Smartphone'  # to jest atrybut klasy
    obiekty = []  # tworzymy liste

    def __init__(self, typ, model, cena):  # konstrukor (tworzy obiekt)
        self.typ = typ  # _ ustawienie na typ chroniny
        self.__model = model  # podstawienie atrybut obiektu na parametf funkcji (TRYB PUBLICZNY
        self.cena = cena  # __ to jest atrybut obiektu (ustawiony na tryp prywatny)
        Telefon.obiekty.append(self)  # do listy obiekty (ktora jest w klasei telefon) dodajemy obiekt
        self.czas = Telefon.aktualna_godzina()


    @staticmethod
    def aktualna_godzina():
        return time.strftime('%H: %M: %S: ')

    @classmethod
    def ile_obiektow(cls):
        if len(Telefon.obiekty) > 0:
            print(f'utworzono', len(Telefon.obiekty), 'obiekty')
        else:
            print('Nie utworzono obiektu')

    @property
    def cena(self):
        return self.__cena

    @cena.setter
    def cena(self, wartosc):
        if isinstance(wartosc, (int, float)):
            if wartosc > 0:
                self.__cena = wartosc
            else:
                raise ValueError('Wartosc musi byc liczba dodatnia')
        else:
            raise ValueError('cena musi byc inf lub float')

    @cena.deleter
    def cena(self):
        del self.__cena

    @property
    def model(self):
        return self.__model

    @model.setter
    def model(self, tekst):
        if isinstance(tekst, str):
            if tekst.isalnum():
                self.__model = tekst
            else:
                raise TypeError('Nie moze zawierac spacj')
        else:
            raise TypeError('Model musi byc stringiem ')

    @property
    def typ(self):
        return self._typ

    @typ.setter
    def typ(self, tekst):
        if isinstance(tekst, str):
            self._typ = tekst
        else:
            raise TypeError('typ musi bys stringiem')
    # tworzenie metody obiektu ( bo self) czyli wewnatr musza byc atrybuty obietku czyli self.

    def __str__(self):
        return (f'Towar: {Telefon.obiekty.index(self)+1} utworzono {self.czas},'
                f'Typ: {self._typ}, Model: {self.model}, Cena: {self.__cena}')
# strzałka oznacza nadpisanie funkcji str ktora znajduje sie w klasie telefon
# tworzenie obietku


telefon1 = Telefon('Samsung', "Galaxy", 5000)
# obiekt tworzony za pomoca konstruktora z trzema parametrami
telefon2 = Telefon('IPhone', '15', 6000)
# zmiana ceny na 4000
# telefon2.cena =4000
# nie trzeba wywoływac jej tylko napisac nazwe obiekut
print(telefon2)
print(telefon1)
Telefon.rodzaj = 'smartfon'
Telefon.ile_obiektow()
telefon2.model = '13'  # zmiana atrybutu model na 13
print(telefon2)
print(telefon1.typ)
print(telefon1)
time.sleep(1)
tel3 = Telefon('Motorola', 'Edge 60 PRO', 4000)
print(tel3)
tel3.cena = 676767
print(tel3)
tel4 = Telefon("LG", 'k10', 250)
print(tel4)
Telefon.ile_obiektow()
