import datetime
import time
import random


class Ksiazka:
    ID = 1

    def __init__(self, tytul, autor):
        self.tytul = tytul
        self.autor = autor
        self.rok = Ksiazka.losuj_rok()
        self.data_zakupu = Ksiazka.aktualna_data()
        self.nr = Ksiazka.ID
        Ksiazka.ID += 1

    @classmethod
    def losuj_rok(cls):
        return random.randint(0, 2025)

    @property
    def tytul(self):
        return self._tytul

    @tytul.setter
    def tytul(self, tekst):
        if isinstance(tekst, str):
            self._tytul = tekst.upper()
        else:
            raise TypeError('Tytuł musi być typu string')

    @property
    def autor(self):
        return self.__autor

    @autor.setter
    def autor(self, tekst2):
        if isinstance(tekst2, str):
            if tekst2.replace(' ', '').isalpha():
                if ' ' in tekst2:
                    self.__autor = tekst2.title()
                else:
                    raise ValueError('Autor musi zawierać spacje między imieniem i nazwiskiem')
            else:
                raise ValueError('Autor nie może zawierać cyfr')
        else:
            raise TypeError('Wprowadzony autor musi być stringiem')

    @autor.deleter
    def autor(self):
        del self.__autor

    # @property
    # def rok(self):
    #     return self._rok

    # @rok.setter
    # def rok(self, wartosc):
    #     if isinstance(wartosc, int):
    #         if len(str(wartosc)) == 4 and wartosc < 2026:
    #             self._rok = wartosc
    #         else:
    #             raise ValueError('Dana liczba musi byc 4-cyfrowa, mniejsza niz 2026')
    #     else:
    #         raise TypeError('Wprowadzona wartosc musi byc liczba')

    @staticmethod
    def aktualna_data():
        return datetime.datetime.today()

    def __str__(self):
        return f'Ksiazka nr {self.nr} "{self.tytul}", {self.autor}, ({self.data_zakupu}, {Ksiazka.losuj_rok()})'


k1 = Ksiazka('Pan Tadeusz', 'Adam Mickiewicz')
print(k1)
time.sleep(2)
k2 = Ksiazka('Wiedzmin', 'Andrzej Sapkowski')
print(k2)
k3 = Ksiazka('Kosmos', 'A I')
print(k3)
k3.autor = 'S I'
print(k3)
