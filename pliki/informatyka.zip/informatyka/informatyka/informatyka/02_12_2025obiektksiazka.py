
class Ksiazka:
    ID = 1

    def __init__(self, tytul, autor, rok_wydania, data_zakupu):
        self.tytul = tytul
        self.autor = autor
        self.__rok = rok_wydania
        self.data_zakupu = data_zakupu
        self.nr = Ksiazka.ID
        Ksiazka.ID += 1
    # static nie ma zwiazku z tematem klasy
    @property
    def tytul(self):
        return self._tytul

    @tytul.setter
    def tytul(self, tekst):
        if isinstance(tekst, str):
            self._tytul = tekst.upper()
        else:
            raise TypeError('Tytuł musi być typu string')

    @autor.setter
    def autor(self, tekst2):
        if isinstance(tekst2, str):
            if tekst2.replace(' ', '').isalpha():
                if ' ' in tekst2:
                    self.__autor = tekst2.title()
                else:
                    ValueError('Autor musi zawierać spacje między imieniem i nazwiskiem')
            else:
                raise ValueError('Autor nie może zawierać cyfr')
        else:
            TypeError('Wprowadzony autor musi być stringiem')

    @autor.deleter
    def autor(self):
        del self.__autor

