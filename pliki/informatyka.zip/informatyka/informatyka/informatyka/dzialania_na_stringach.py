def licz_cyfry(a, b):
    suma = 0
    for cyfra in a+b:
        if int(cyfra) % 2 == 0:
            suma += int(cyfra)
    return suma


def licz_kwadraty(a, b):
    suma = 0
    for cyfra in a+b:
        suma += int(cyfra)*int(cyfra)
    return suma


n = input('Wprowadź liczbę w systemie szóstkowym: ')
while not n.isdigit():
    n = input('Błąd. Wprowadź jeszcze raz: ')
p = input('Wprowadź liczbę w systemie szóstkowym: ')
while not p.isdigit():
    p = input('Błąd. Wprowadź jeszcze raz: ')
n_dz = int(n, 6)
p_dz = int(p, 6)
print(f'Liczba {n} w systemie dziesiętnym to {n_dz}.')
print(f'Liczba {p} w systemie dziesiętnym to {p_dz}.')
if n_dz % p_dz == 0 or p_dz % n_dz == 0:
    print(f'Jedna z tych liczb jest dzielnikiem drugiej. ')
else:
    print(f'Żadna z tych liczb nie dzieli się przez drugą. ')
print(f'Suma cyfr parzystych obu liczb wynosi {licz_cyfry(n, p)}.')
print(f'Suma kwadratów cyfr obu liczb wynosi {licz_kwadraty(n, p)}.')
warunek = True
for j in range(len(str(p))-1):
    if int(p[j]) == 5 and int(p[j+1]) == 5:
        print(f'W drugiej liczbie występuje ciąg \'55\'.')
        warunek = False
        break
if warunek:
    print(f'W drugiej liczbie nie wystepuje ciąg \'55\'.')
