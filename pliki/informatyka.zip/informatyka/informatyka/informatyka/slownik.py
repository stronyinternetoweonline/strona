slownik={} #tworzymy slownik
produkty={'mleko':4, 'maslo':13, 'kefir':3, 'nabial':{'ser':34, 'twarog':7}} #klucz:wartosc
#slownik to para
print(produkty)
for element in produkty.keys(): #wypisanie kluczy
    print(element)
print( )
print(produkty.keys()) #wypisanie kluczow za pomoca lista
print( )
for wartosc in produkty.values(): #wypisanie wartosci
    print(wartosc)
print( )
print(produkty.values()) #wypisanie wartosci za pomoca lista
print( )
for klucz, wartosc in produkty.items():
    print(klucz, ':', wartosc)
print( )

produkty['jajka']=12 #dodaje do slownik
print(produkty)

print( )

produkty['mleko']=6
print(produkty) #aktualizacja rekordu

print()

print(produkty['jajka'])
print(produkty['nabial']['ser']) #wypisanie wartosci dla klucza

print( )

# del produkty['kefir'] #usuwamy produkt ze slownika
produkty.pop('kefir') #usuwamy produkt ze slownika sposob2
print(produkty)

print( )

produkty.popitem() #usuwa ostatnik element slownika
print(produkty)

print()

owoce=['jablka', 'gruszki', 'sliwki'] #tworzenie 2 list
ceny_owocow=[4, 8, 6]
produkty_owoce= dict(zip(owoce, ceny_owocow)) #tworzenie slownika z dwoch list
print(produkty_owoce)

print( )

warzywa=['ziemniaki', 'buraki', 'marchew']
warzywa_slownik=dict.fromkeys(warzywa) #tworzenie slownika bez wartosci
print(warzywa_slownik)

print( )

produkty.update(produkty_owoce) #dodanie do slownika do slownika
print(produkty)
produkty.update(warzywa_slownik)
print(produkty)

produkty['ziemnaiki']=2
produkty['buraki']=7
produkty['marchwe']=3.5
print(produkty)

tekst=input('podaj tekst')
licz_litery={}
for litera in tekst.upper():
    if litera!='':
        if litera not in licz_litery:
            licz_litery[litera]=1
        else:
            licz_litery[litera]+=1

print(licz_litery)