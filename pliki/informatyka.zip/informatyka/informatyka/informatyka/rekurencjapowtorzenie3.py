


def ulamkiI(n):
    wynik=(1+3)/n
    suma=wynik
    for i in range(1, n):
        wynik=wynik+(1/n)
        suma+=wynik
    return suma

def ulamkiR(i, n):
    if i ==1:
        return 4/n
    return (i+3)/n + ulamkiR(i-1, n)
def ulamkiR2(n):
    if n == 1:
        return (n+3)/n
    elif n ==2:
        return ((n+3)/n)+((n+2)/n)+((n+1)/n)
    else:
        return 1+ulamkiR2(n-2)

n = int(input('Podaj liczbe naturalna: '))
print(ulamkiI(n))
print(f'wynik to: {ulamkiR2(n)}')