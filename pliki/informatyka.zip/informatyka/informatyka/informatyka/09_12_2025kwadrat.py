import math


class Kwadrat:
    ID = 0

    def __init__(self, bok):
        if isinstance(bok, (int, float)):
            if bok > 0:
                self._bok = bok
            else:
                raise ValueError('Bok kwadratu musi byc liczba dodatnia')
        else:
            raise TypeError('Bok kwadratu musi byc liczba')

        self.nr = Kwadrat.numerowanie()

    @classmethod
    def numerowanie(cls):
        cls.ID += 1
        return cls.ID

    def oblicz_pole(self):
        return self._bok * self._bok

    def oblicz_obwod(self):
        return 4 * self._bok

    def oblicz_przekatna(self):
        return math.sqrt(2) * self._bok
    # to nie funkcja obiektu bo jest wprowadzana przez uzytkownika i
    # jest tak naprawde statyczna bo nie operuje na atrybutach obiektu

    def __str__(self):
        return f'Kwadrat nr {self.nr} ma bok {self._bok} i pole {self.oblicz_pole()}'


k1 = Kwadrat(1)
print(k1)
k2 = Kwadrat(10)
print(k2)
k3 = Kwadrat(3)
print(k3)
k1._bok = 2
print(k1)
