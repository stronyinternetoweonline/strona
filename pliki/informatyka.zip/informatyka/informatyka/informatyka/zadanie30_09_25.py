n = (input("Wprowadź pierwszą liczbę w systemie szostkowym(0, 5): "))
m = (input("Wprowadź drugą liczbę w systemie szostkowym(0, 5): "))
# zamiana na system osemkowy
# [2:] usuwa 0b przed wynikiem
def zad1(liczba):
    return oct(int(n, 6))[2: ]
dzies=int(n, 6)

# czy jedna liczba jest dzielnikiem drugiej
def zad2(n, m):
    return int(n, 6) % int(m, 6) == 0 or int(m, 6) % int(n, 6) == 0

# suma wszystkich cyfr parzystych
def zad3(l1, l2):
    suma = 0
    for cyfra in l1+l2:
        if int(cyfra) % 2 == 0:
            suma += int(cyfra)
    return suma

# sprawdzic czy w drugiej liczbie wystepuje 5, 5
def zad4(liczba):
    return liczba.count("55")>=1

# suma kwadratów wszystkich cyfr
def zad5(l1, l2):
    suma = 0
    for cyfra in l1+l2:
        suma += int(cyfra) * int(cyfra)
    return suma
print(dzies)
print(zad2(n, m))
print(zad3(n, m))
print(f"Zawiera ciąg 55 {zad4(n)}")
print(f'Suma kwadratów{zad5(n, m)}')



