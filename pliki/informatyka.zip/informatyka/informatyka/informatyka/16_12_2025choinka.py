# choinki: świerk pospolity, świerk kłujący, jodła, jodła kaukaska, sosna
# string wypisuje numer, nazwe, wysokosc i srednia ocene
# metoda: jezeli wysokosc ponizej 2m to nazwa to nazwa + mala a jak powyzej to nazwa = duza
import random


class Choinki:
    def __init__(self, nazwa, wysokosc):
        if isinstance(nazwa, str):
            self.__nazwa = nazwa
        else:
            raise TypeError('Nazwa musi być typu string')
        if isinstance(wysokosc, (int, float)):
            if wysokosc > 0:
                if wysokosc <= 2:
                    self.nazwa = nazwa + ' mala/y'
                else:
                    self.nazwa = nazwa + ' duza/y'
                self.wysokosc = wysokosc
            else:
                raise ValueError('Nie istnieje tak mała choinka')
        else:
            raise TypeError('Wysokość choinki musi być liczbą')

        self._oceny = []

    @property
    def ocena(self):
        if len(self._oceny) == 0:
            return 'Brak ocen'
        else:
            return round(sum(self._oceny)/len(self._oceny), 2)

    @ocena.setter
    def ocena(self, ocena):
        if isinstance(ocena, int):
            if 0 < ocena < 11:
                self._oceny.append(ocena)
            else:
                raise ValueError('Ocen w skali 1-10')
        else:
            raise TypeError('Ocena musi być liczbą')

    def __str__(self):
        return f'gatunek: {self.nazwa}, średnia ocena {self.ocena} na {len(self._oceny)} ocen'


drzewka = ['jodła', 'jodła kaukaska', 'świerk', 'świerk pospolity', 'świerk kłujący', 'sosna']
obiekt = []
for i in range(len(drzewka)):
    obiekt.append(Choinki(drzewka[i], random.randint(1, 6)))

for i in range(len(obiekt)):
    for _ in range(0, random.randint(1, 9999)):
        obiekt[i].ocena = random.randint(1, 10)
# obiekt[0].ocena = 1
# obiekt[0].ocena = 2
# obiekt[1].ocena = 3
for el in obiekt:
    print(el)

ch1 = Choinki('jodla', 4)
ch2 = Choinki('swierk', 1.6)
# ch1.ocena = 1
# ch1.ocena = 2
# ch1.ocena = 3
