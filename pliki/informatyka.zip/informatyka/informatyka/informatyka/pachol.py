n = input("Podaj liczbe naturalna dodatnia: ")
n = int(n)

def rekurencja(n):
    lista = [1,1]
    if n == 1:
        lista.pop()
        return 1
    if n == 2:
        return 1
    else:
        return rekurencja(n-1) * 2 + rekurencja(n-2)
for i in range(1, n):
    print(rekurencja(i))



print(rekurencja(n))
