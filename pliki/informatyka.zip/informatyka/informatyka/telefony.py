#zajmujemy sie telefonami
#----------------------------
#atrybuty ktore nie sa w konstruktoze to atrybuty klasy
#------------------
#tworzymy klase
class Telefon:
    rodzaj='Smartphone' # to jest atrybut klasy

    def __init__(self,typ ,model , cena): #konstrukor, funkcja przyjmujaca nazwe klasy, self jest gfy funkcja dotyczy obiektu
        self._typ=typ #_ ustawienie na typ chroniny
        self.model=model #podstawienie atrybut obiektu na parametf funkcji (TRYB PUBLICZNY
        self.__cena=cena # to jest atrybut obiektu (ustawiony na tryp prywatny)
    # chroniony jest dostepny w pochodnych a prywatny tylko w obrebie klasy
    # strzałka to nadpisanie w 16 linijce
    #tworzenie metody obiektu ( bo self) czyli wewnatr musza byc atrybuty obietku czyli self.
    def __str__(self):
        return f'Towar: {Telefon.rodzaj},Typ: {self._typ}, Model: {self.model}, Cena: {self.__cena}'

#tworzenie obietku
telefon1=Telefon('Samsung',"Galaxy", 5000)
#obiekt tworzony za pomoca konstruktora z trzema parametrami

print(telefon1.__str__())

print(f'Model to: {telefon1.model}')


telefon2=Telefon('IPhone', '15', 6000)
print(telefon2.__str__())

print(telefon1.__str__())

print(Telefon.__dict__)
 #zmiana ceny na 4000
# telefon2.cena =4000
#nie trzeba wywoływac jej tylko napisac nazwe obiekut
print(telefon2)
print(telefon1)
Telefon.rodzaj='smartfon'
telefon2.model='13'
print(telefon2)


# telefon1.cena=-5000
print(telefon1._typ)
print(Telefon.__dict__)
print(telefon1._Telefon__cena)