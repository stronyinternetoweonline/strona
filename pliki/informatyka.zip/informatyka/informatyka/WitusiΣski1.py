n = int(input("Podaj liczbe: "))
def funkcjar(n):
    if n == 1:
        return 4
    elif n == 2:
        return 0
    elif n == 3:
        return 1
    else:
        return - funkcjar(n-1) - funkcjar(n-2) + funkcjar(n-3)

def funkcjai(n):
    wynik=1
    ppp=1
    pp=1
    p=1
    for i in range(3, n-3):
        p= -pp + ppp
        pp = ppp
        wynik = -p
    return wynik

print("funkcja rekurencyjna: ")
for i in range(1, n):
    print(funkcjar(i))
print("funkcja iteracyjna: ")
for i in range(1, n):
    print(funkcjai(i))
