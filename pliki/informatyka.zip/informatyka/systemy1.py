n = int(input('Podaj liczbe naturalna'))
binarna = bin(n)[2:]
print(binarna)
# czy liczba binarna ma taki sam pierwszy i ostatni znak ale nie chcemy 0b
liczba = int(binarna, 2)
print(liczba)
print(int('121', 7))
# bin zamienia inty na binarne, int zamienia na dziesietna
# Schemat Hornera:
# np. (10101011) w systemie dwojkowym to =(1*2+0)*2+1)*2+0)*2+1)*2+0)*2+1)*2+1 to się równa 171
# Homer działa szybciej niz inne sposoby, mniej obliczeń
# (12120) w systemie trójkowym to = (1*3+2)*3+1)*3+2)*3+0=
# (1012300) w systemie czwórkowym to = (1*4+0)*4+1)*4+2)*4+3)*4+3)*4+0)*4+0=4528
# sprawdzic czy dana liczba binarna jest parzysta
# wersja z sprawdzaniem czy sie dzieli
if int(binarna, 2) % 2 == 0:
    print("liczba jest parzysta")
else:
    print("Liczba nie jest parzysta")
# wersja ze sprawdzaniem czy ostatnia liczba to 0
if binarna[-1] == "0":
    print('Liczba jest parzysta')
else:
    print('Liczba nie jest parzysta')

# sprawdzic czy dana liczba binarna jest podzielna przez 4
# kiedy dwie ostatnie cyfry to zero
if binarna[-1] == "0" and binarna[-2] == "0":
    print("Liczba jest podzielna przez 4")
else:
    print("Liczba nie jest podzielna przez 4")


# druga metoda pewniejsza bo pierwsza nie działa dla 0
if binarna == "0" or binarna[-1] == "0" and binarna[-2] == "0":
    print("Liczba jest podzielna przez 4")
else:
    print("Liczba nie jest podzielna przez 4")
#     sprawdzic czy jest podzielna przez 7
if int(binarna, 2) % 7 == 0:
    print("Liczba jest podzielna przez 7")
else:
    print("Liczba nie jest podzielna przez 7")
# sprawdz czy ostatnia cyfra liczby dziesietnej jest taka sama jak ostatnia cyfra tej samej liczby zamienianej na binarna
def bind(n):
    binarna=bin(n)[2:]
    return binarna[-1] == str(n)[-1]
print(bind(n))

# print("Ostatnia cyfra liczby binarnej jest taka sama jak ostatnia cyfra liczby dziesiętnej")