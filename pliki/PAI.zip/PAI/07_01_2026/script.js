document.getElementById("wyslij").addEventListener("click", function () {
    const imie = document.getElementById("imie").value;
    const nazwisko = document.getElementById("nazwisko").value;
    const regulamin = document.getElementById("regulamin").checked;
    const komunikat = document.getElementById("komunikat");

    if (imie === "" || nazwisko === "") {
        komunikat.innerHTML = "Uzupełnij imię i nazwisko!";
        komunikat.style.color = "red";
        return;
    }

    if (!regulamin) {
        komunikat.innerHTML = "Musisz zaakceptować regulamin!";
        komunikat.style.color = "red";
        return;
    }

    komunikat.innerHTML = "Witaj <b>" + imie + " " + nazwisko + "</b>";
    komunikat.style.color = "green";
});
