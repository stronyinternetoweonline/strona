def fiborek(n):
    if n==1 or n==2:
        return 1
    return fiborek(n-1) + fiborek(n-2)
def fiboite(n):
    pp=1
    p=1
    for i in range(3, n+1):
        wynik=pp+p
        pp=p
        p=wynik
    return p

n=input("który wyraz szukać")
while not n.isdecimal():
    n=input('Blad. Podaj liczbe naturalna')
n=int(n)
print(f'{n} to wyraz ciagu = {fiboite(n)}')
print(f'{n} to wyraz ciagu = {fiborek(n)}')
