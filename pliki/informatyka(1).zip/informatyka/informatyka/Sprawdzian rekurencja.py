

def funkcjar(n):
    if n==2 or n==3 :
        return 1
    else:
        return funkcjar(n/2) + funkcjar(n*2)


def funkcjai(n):
    a=1
    wynik=1
    for i in range(n):
        wynik *= a
    return wynik

n=int(input('podaj liczbe'))
print (funkcjar(n))
print (funkcjai(n))







